
import React from 'react'

function AskDoubtsForClass() {
  return (
    <div>AskDoubtsForClass</div>
  )
}

export default AskDoubtsForClass
